#ifndef MEMCPY_H
#define MEMCPY_H
/* Serve per copiare, ad esempio, strutture dati */
void *memcpy(void *, const void *, unsigned int );

#endif